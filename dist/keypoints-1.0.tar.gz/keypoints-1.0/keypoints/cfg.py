row_img_path = '/home/think/文档/xray/dir_test/'

transfer_dir = '/home/think/文档/xray/transfer_dir/'

result_dir = '/home/think/文档/xray/result_duiqidu/'

pixl_dict = {'1':0.022,
        '2':0.020,
        '3':0.016,
        '4':0.014}

test_points = {'1':'Test Point A',
               '2':'Test Point B',
               '3':'Test Point C',
               '4':'Test Point D'}

lowe_limit = 0.92

up_limit = {'1':2.62,
            '2':2.97,
            '3':2.97,
            '4':2.62}

edges = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9], [10, 11], [12, 13], [14, 15], [16, 17], [18, 19], [20, 21], [22, 23], [24, 25], 
         [26, 27], [28, 29], [30, 31], [32, 33], [34, 35], [36, 37], [38, 39], [40, 41], [42, 43], [44, 45], [46, 47], [48, 49], 
         [50, 51], [52, 53], [54, 55], [56, 57], [58, 59], [60, 61], [62, 63], [63, 64]]